DUNAB - Sistema de interacción estudiantil
Proyecto Java Swing para Apache NetBeans.

REQUISITOS
- JDK 8 o superior.
- Apache NetBeans con soporte para proyectos Java/Ant.

ABRIR EL PROYECTO
1. Extrae el ZIP en una carpeta de tu equipo.
2. En NetBeans selecciona File > Open Project.
3. Selecciona la carpeta SistemaEstudiantilUNAB (la que contiene build.xml y nbproject).
4. Ejecuta el proyecto con Run Project (F6).

FUNCIONALIDADES
- Registro de estudiantes con validación de código y correo.
- Inicio de sesión usando código o correo y contraseña.
- Consulta de estudiantes registrados.
- Perfil del estudiante y actualización de nombre/correo.
- Creación, edición y eliminación de encuentros (solo el creador puede editar/eliminar).
- Búsqueda y filtro por categoría de encuentros.
- Inscripción y cancelación de inscripción con control de cupos.
- Historial persistente de acciones del estudiante.
- Ranking de participación.
- Notificaciones persistentes, con opción de marcar una o todas como leídas.
- Panel de progreso con meta de 10.000 DUNAB y recompensas distintas por categoría.
- Encuentros de ejemplo precargados: Estudio, Académico, Social y Deportivo.
- Los DUNAB se otorgan únicamente al inscribirse; cancelar la inscripción retira la recompensa.

PERSISTENCIA
Los datos se guardan localmente en la carpeta datos, que se crea automáticamente:
- datos/usuarios.dat
- datos/encuentros.dat
- datos/actividades.dat
- datos/notificaciones.dat

NOTAS
- Es un prototipo académico de escritorio; el almacenamiento es local al equipo donde se ejecuta.
- El módulo de progreso mide participación dentro de DUNAB, no calificaciones académicas oficiales.
- Para probar con una cuenta nueva, selecciona Crear una cuenta desde la pantalla inicial.
