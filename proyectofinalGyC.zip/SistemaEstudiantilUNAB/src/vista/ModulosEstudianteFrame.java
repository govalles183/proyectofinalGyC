package vista;

import datos.GestorActividad;
import datos.GestorEncuentros;
import datos.GestorNotificaciones;
import modelo.Actividad;
import modelo.Encuentro;
import modelo.Notificacion;
import modelo.Usuario;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.*;
import java.util.List;

/** Módulos persistentes de historial, ranking, notificaciones y progreso. */
public class ModulosEstudianteFrame extends JFrame {
    private final Usuario usuario;
    private final String codigo;
    private final GestorActividad actividades = new GestorActividad();
    private final GestorNotificaciones notificaciones = new GestorNotificaciones();
    private final GestorEncuentros encuentros = new GestorEncuentros();
    private final DefaultTableModel notifModel = new DefaultTableModel(new Object[]{"Estado","Fecha","Notificación","Detalle","ID"},0){public boolean isCellEditable(int r,int c){return false;}};
    private final JTable notifTabla = new JTable(notifModel);
    private final DefaultTableModel histModel = new DefaultTableModel(new Object[]{"Fecha","Acción","Detalle"},0){public boolean isCellEditable(int r,int c){return false;}};
    private final JTable histTabla = new JTable(histModel);

    public ModulosEstudianteFrame(Usuario usuario, String modulo) {
        this.usuario=usuario; this.codigo=usuario.getEstudiante().getCodigo();
        setTitle("DUNAB | " + modulo); setSize(900,590); setLocationRelativeTo(null); setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        JTabbedPane tabs=new JTabbedPane();
        tabs.addTab("Historial", panelHistorial());
        tabs.addTab("Ranking", panelRanking());
        tabs.addTab("Notificaciones ("+notificaciones.noLeidas(codigo)+")", panelNotificaciones());
        tabs.addTab("Mi progreso", panelProgreso());
        int index=0; if("Historial".equalsIgnoreCase(modulo))index=0; else if("Ranking".equalsIgnoreCase(modulo))index=1; else if("Notificaciones".equalsIgnoreCase(modulo))index=2; else if("Mi progreso".equalsIgnoreCase(modulo))index=3;
        tabs.setSelectedIndex(index); add(tabs);
    }
    private JPanel panelHistorial(){JPanel p=new JPanel(new BorderLayout(10,10));p.setBorder(BorderFactory.createEmptyBorder(18,18,18,18));JLabel info=new JLabel("Registro de las acciones que has realizado en DUNAB.");p.add(info,BorderLayout.NORTH);histTabla.setRowHeight(25);p.add(new JScrollPane(histTabla),BorderLayout.CENTER);JButton refresh=new JButton("Actualizar");refresh.addActionListener(e->cargarHistorial());p.add(refresh,BorderLayout.SOUTH);cargarHistorial();return p;}
    private void cargarHistorial(){histModel.setRowCount(0);for(Actividad a:actividades.historial(codigo))histModel.addRow(new Object[]{a.getFecha().toString().replace('T',' '),a.getAccion(),a.getDetalle()});}
    private JPanel panelNotificaciones(){JPanel p=new JPanel(new BorderLayout(10,10));p.setBorder(BorderFactory.createEmptyBorder(18,18,18,18));p.add(new JLabel("Tus avisos de inscripciones, encuentros y cambios."),BorderLayout.NORTH);notifTabla.setRowHeight(25);p.add(new JScrollPane(notifTabla),BorderLayout.CENTER);JPanel acciones=new JPanel(new FlowLayout(FlowLayout.RIGHT));JButton leer=new JButton("Marcar seleccionada como leída"),todas=new JButton("Marcar todas como leídas"),actualizar=new JButton("Actualizar");leer.addActionListener(e->{int r=notifTabla.getSelectedRow();if(r>=0){int id=(int)notifModel.getValueAt(notifTabla.convertRowIndexToModel(r),4);notificaciones.marcarLeida(id,codigo);cargarNotificaciones();}});todas.addActionListener(e->{notificaciones.marcarTodas(codigo);cargarNotificaciones();});actualizar.addActionListener(e->cargarNotificaciones());acciones.add(leer);acciones.add(todas);acciones.add(actualizar);p.add(acciones,BorderLayout.SOUTH);cargarNotificaciones();return p;}
    private void cargarNotificaciones(){notifModel.setRowCount(0);for(Notificacion n:notificaciones.listar(codigo))notifModel.addRow(new Object[]{n.isLeida()?"Leída":"Nueva",n.getFecha().toString().replace('T',' '),n.getTitulo(),n.getMensaje(),n.getId()});}
    private JPanel panelRanking(){JPanel p=new JPanel(new BorderLayout(10,10));p.setBorder(BorderFactory.createEmptyBorder(18,18,18,18));Map<String,Integer> puntos=encuentros.ranking();List<Map.Entry<String,Integer>> lista=new ArrayList<Map.Entry<String,Integer>>(puntos.entrySet());lista.sort((a,b)->b.getValue().compareTo(a.getValue()));DefaultTableModel m=new DefaultTableModel(new Object[]{"Posición","Código estudiante","Participaciones"},0){public boolean isCellEditable(int r,int c){return false;}};int pos=1;for(Map.Entry<String,Integer> e:lista)m.addRow(new Object[]{pos++,e.getKey(),e.getValue()});JTable t=new JTable(m);t.setRowHeight(27);p.add(new JLabel("Ranking calculado según encuentros creados e inscripciones activas."),BorderLayout.NORTH);p.add(new JScrollPane(t),BorderLayout.CENTER);JLabel pie=new JLabel("Encuentros publicados: "+encuentros.total()+"   |   Inscripciones activas: "+encuentros.totalInscripciones());p.add(pie,BorderLayout.SOUTH);return p;}
    private JPanel panelProgreso(){
        JPanel p=new JPanel(new BorderLayout(14,14));
        p.setBorder(BorderFactory.createEmptyBorder(22,22,22,22));
        int objetivo=10000;
        int puntos=encuentros.puntosDunab(codigo);
        int inscritos=encuentros.cantidadInscripciones(codigo);
        int avance=Math.min(100,(int)Math.round(puntos*100.0/objetivo));

        JPanel superior=new JPanel(new BorderLayout(8,12));
        JLabel titulo=new JLabel("Mi progreso DUNAB");titulo.setFont(new Font("Arial",Font.BOLD,23));
        JLabel subtitulo=new JLabel("Gana DUNAB al inscribirte en encuentros universitarios.");subtitulo.setForeground(Color.DARK_GRAY);
        JPanel textos=new JPanel(new GridLayout(2,1,3,3));textos.setOpaque(false);textos.add(titulo);textos.add(subtitulo);
        superior.add(textos,BorderLayout.NORTH);
        JPanel barraPanel=new JPanel(new BorderLayout(8,8));
        JLabel resumen=new JLabel("Llevas "+puntos+" / "+objetivo+" DUNAB  •  "+avance+"% del objetivo");resumen.setFont(new Font("Arial",Font.BOLD,16));
        JProgressBar barra=new JProgressBar(0,100);barra.setValue(avance);barra.setStringPainted(true);barra.setString(avance+"%");barra.setPreferredSize(new Dimension(100,28));barra.setForeground(Estilos.NARANJA);
        JLabel restante=new JLabel(puntos>=objetivo?"¡Meta de 10.000 DUNAB alcanzada!":"Te faltan "+(objetivo-puntos)+" DUNAB para alcanzar tu meta.");
        barraPanel.add(resumen,BorderLayout.NORTH);barraPanel.add(barra,BorderLayout.CENTER);barraPanel.add(restante,BorderLayout.SOUTH);superior.add(barraPanel,BorderLayout.CENTER);
        p.add(superior,BorderLayout.NORTH);

        JPanel centro=new JPanel(new BorderLayout(10,10));
        JPanel cards=new JPanel(new GridLayout(1,2,12,12));
        cards.add(card("Inscripciones activas",String.valueOf(inscritos),"Encuentros en los que participas"));
        cards.add(card("DUNAB acumulados",String.valueOf(puntos),"Solo cuentan inscripciones activas"));
        centro.add(cards,BorderLayout.NORTH);
        DefaultTableModel reglas=new DefaultTableModel(new Object[]{"Categoría","DUNAB por inscripción","Inscripciones","Total DUNAB"},0){public boolean isCellEditable(int r,int c){return false;}};
        String[][] cats={{"Estudio","100"},{"Académico","200"},{"Social","150"},{"Deportivo","250"}};
        for(String[] cat:cats){int cantidad=encuentros.cantidadPorCategoria(codigo,cat[0]);int total=encuentros.puntosPorCategoria(codigo,cat[0]);reglas.addRow(new Object[]{cat[0],cat[1],cantidad,total});}
        JTable tablaPuntos=new JTable(reglas);tablaPuntos.setRowHeight(27);
        JPanel detalle=new JPanel(new BorderLayout(5,5));detalle.add(new JLabel("Recompensas por categoría"),BorderLayout.NORTH);detalle.add(new JScrollPane(tablaPuntos),BorderLayout.CENTER);
        centro.add(detalle,BorderLayout.CENTER);p.add(centro,BorderLayout.CENTER);
        JLabel nota=new JLabel("Crear, editar o publicar encuentros no da puntos. Al cancelar una inscripción, se descuentan los DUNAB de esa actividad.");nota.setForeground(Color.DARK_GRAY);p.add(nota,BorderLayout.SOUTH);
        return p;
    }
    private JPanel card(String titulo,String valor,String detalle){JPanel c=new JPanel(new GridLayout(3,1,4,4));c.setBackground(Color.WHITE);c.setBorder(BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(225,225,225)),BorderFactory.createEmptyBorder(18,18,18,18)));JLabel t=new JLabel(titulo);t.setFont(new Font("Arial",Font.BOLD,15));JLabel v=new JLabel(valor);v.setFont(new Font("Arial",Font.BOLD,30));v.setForeground(Estilos.NARANJA);JLabel d=new JLabel(detalle);d.setForeground(Color.GRAY);c.add(t);c.add(v);c.add(d);return c;}
}
