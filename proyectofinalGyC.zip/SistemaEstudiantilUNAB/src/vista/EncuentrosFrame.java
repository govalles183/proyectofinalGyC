package vista;
import datos.GestorEncuentros;
import datos.GestorNotificaciones;
import datos.GestorActividad;
import modelo.Encuentro;
import modelo.Usuario;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.time.LocalDate;
import java.util.*;
public class EncuentrosFrame extends JFrame {
    private final GestorEncuentros gestor=new GestorEncuentros();
    private final GestorNotificaciones notificaciones=new GestorNotificaciones();
    private final GestorActividad actividad=new GestorActividad();
    private final Usuario usuario;
    private final DefaultTableModel modelo=new DefaultTableModel(new Object[]{"ID","Encuentro","Materia","Fecha","Categoría","Lugar","Inscritos","Cupos libres"},0){public boolean isCellEditable(int r,int c){return false;}};
    private final JTable tabla=new JTable(modelo);
    private final JTextField buscar=new JTextField(15);
    private final JComboBox<String> categoria=new JComboBox<String>(new String[]{"Todas","Estudio","Académico","Social","Deportivo"});
    public EncuentrosFrame(Usuario u){
        usuario=u;setTitle("DUNAB | Encuentros");setSize(950,570);setLocationRelativeTo(null);setDefaultCloseOperation(DISPOSE_ON_CLOSE);setLayout(new BorderLayout(8,8));
        JPanel top=new JPanel(new FlowLayout(FlowLayout.LEFT));top.add(new JLabel("Buscar:"));top.add(buscar);top.add(new JLabel("Categoría:"));top.add(categoria);
        JButton filtrar=new JButton("Aplicar filtro"),limpiar=new JButton("Mostrar todos");top.add(filtrar);top.add(limpiar);add(top,BorderLayout.NORTH);
        tabla.setRowHeight(25);add(new JScrollPane(tabla),BorderLayout.CENTER);
        JPanel acciones=new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton crear=new JButton("Crear"),editar=new JButton("Editar"),eliminar=new JButton("Eliminar"),inscribir=new JButton("Inscribirme"),cancelar=new JButton("Cancelar inscripción"),historial=new JButton("Mi historial"),ranking=new JButton("Ranking / estadísticas");
        for(JButton b:new JButton[]{crear,editar,eliminar,inscribir,cancelar,historial,ranking})acciones.add(b);add(acciones,BorderLayout.SOUTH);
        crear.addActionListener(e->crear());editar.addActionListener(e->editar());eliminar.addActionListener(e->eliminar());inscribir.addActionListener(e->accionInscripcion(true));cancelar.addActionListener(e->accionInscripcion(false));historial.addActionListener(e->mostrarHistorial());ranking.addActionListener(e->mostrarRanking());
        filtrar.addActionListener(e->actualizar(gestor.buscarTexto(buscar.getText()),(String)categoria.getSelectedItem()));limpiar.addActionListener(e->{buscar.setText("");categoria.setSelectedIndex(0);actualizar();});
        actualizar();
    }
    private int idSeleccionado(){int r=tabla.getSelectedRow();return r<0?-1:(int)modelo.getValueAt(tabla.convertRowIndexToModel(r),0);}
    private void actualizar(){actualizar(gestor.listar(),"Todas");}
    private void actualizar(java.util.List<Encuentro> lista,String cat){modelo.setRowCount(0);for(Encuentro e:lista)if("Todas".equals(cat)||cat.equals(e.getCategoria()))modelo.addRow(new Object[]{e.getId(),e.getTitulo(),e.getMateria(),e.getFecha(),e.getCategoria(),e.getLugar(),e.getInscritos().size(),e.getCuposDisponibles()});}
    private void crear(){
        JTextField t=new JTextField(),m=new JTextField(),d=new JTextField(),l=new JTextField(),f=new JTextField(LocalDate.now().plusDays(1).toString()),c=new JTextField("10");
        JComboBox<String> cat=new JComboBox<String>(new String[]{"Estudio","Académico","Social","Deportivo"});
        Object[] campos={"Título",t,"Materia",m,"Descripción",d,"Lugar",l,"Fecha (AAAA-MM-DD)",f,"Cupos",c,"Categoría",cat};
        if(JOptionPane.showConfirmDialog(this,campos,"Crear encuentro",JOptionPane.OK_CANCEL_OPTION)==JOptionPane.OK_OPTION)try{
            boolean ok=gestor.crear(t.getText(),m.getText(),d.getText(),usuario.getEstudiante().getCodigo(),l.getText(),(String)cat.getSelectedItem(),LocalDate.parse(f.getText()),Integer.parseInt(c.getText()));
            if(!ok)throw new IllegalArgumentException();actividad.registrar(usuario.getEstudiante().getCodigo(),"Creó un encuentro",t.getText());notificaciones.agregar(usuario.getEstudiante().getCodigo(),"Encuentro creado", "Tu encuentro "+t.getText()+" fue publicado.");actualizar();mensaje("Encuentro creado.");
        }catch(Exception ex){mensaje("Verifica los campos, la fecha y que los cupos sean un número positivo.");}
    }
    private void editar(){
        int id=idSeleccionado();Encuentro e=gestor.buscar(id);if(e==null){mensaje("Selecciona un encuentro.");return;}if(!e.getCreadorCodigo().equals(usuario.getEstudiante().getCodigo())){mensaje("Solo quien creó el encuentro puede editarlo.");return;}
        JTextField t=new JTextField(e.getTitulo()),m=new JTextField(e.getMateria()),d=new JTextField(e.getDescripcion()),l=new JTextField(e.getLugar()),f=new JTextField(e.getFecha().toString()),c=new JTextField(""+e.getCupoMaximo());JComboBox<String> cat=new JComboBox<String>(new String[]{"Estudio","Académico","Social","Deportivo"});cat.setSelectedItem(e.getCategoria());
        Object[] x={"Título",t,"Materia",m,"Descripción",d,"Lugar",l,"Fecha (AAAA-MM-DD)",f,"Cupos",c,"Categoría",cat};
        if(JOptionPane.showConfirmDialog(this,x,"Editar encuentro",JOptionPane.OK_CANCEL_OPTION)==JOptionPane.OK_OPTION)try{if(!gestor.editar(id,t.getText(),m.getText(),d.getText(),l.getText(),(String)cat.getSelectedItem(),LocalDate.parse(f.getText()),Integer.parseInt(c.getText())))throw new Exception();actividad.registrar(usuario.getEstudiante().getCodigo(),"Editó un encuentro",t.getText());actualizar();mensaje("Encuentro actualizado.");}catch(Exception ex){mensaje("No se pudo editar. Revisa fecha y cupos.");}
    }
    private void eliminar(){int id=idSeleccionado();if(id<0){mensaje("Selecciona un encuentro.");return;}Encuentro e=gestor.buscar(id);if(e==null)return;if(JOptionPane.showConfirmDialog(this,"¿Eliminar el encuentro seleccionado?","Confirmar",JOptionPane.YES_NO_OPTION)!=JOptionPane.YES_OPTION)return;if(gestor.eliminar(id,usuario.getEstudiante().getCodigo())){for(String cod:e.getInscritos())notificaciones.agregar(cod,"Encuentro cancelado", "El encuentro "+e.getTitulo()+" fue eliminado por su creador.");actividad.registrar(usuario.getEstudiante().getCodigo(),"Eliminó un encuentro",e.getTitulo());actualizar();mensaje("Encuentro eliminado.");}else mensaje("Solo puedes eliminar encuentros creados por ti.");}
    private void accionInscripcion(boolean alta){int id=idSeleccionado();if(id<0){mensaje("Selecciona un encuentro.");return;}Encuentro e=gestor.buscar(id);if(e==null)return;String cod=usuario.getEstudiante().getCodigo();boolean ok=alta?gestor.inscribir(id,cod):gestor.cancelar(id,cod);if(ok){if(alta){notificaciones.agregar(cod,"Inscripción confirmada","Te inscribiste en: "+e.getTitulo());notificaciones.agregar(e.getCreadorCodigo(),"Nuevo participante",usuario.getEstudiante().getNombre()+" se inscribió en "+e.getTitulo());actividad.registrar(cod,"Se inscribió",e.getTitulo()+" | "+e.getCategoria()+" | +"+e.getRecompensaDunab()+" DUNAB");}else{notificaciones.agregar(cod,"Inscripción cancelada","Cancelaste tu inscripción en: "+e.getTitulo());notificaciones.agregar(e.getCreadorCodigo(),"Participante retirado",usuario.getEstudiante().getNombre()+" canceló su inscripción en "+e.getTitulo());actividad.registrar(cod,"Canceló inscripción",e.getTitulo()+" | Se retiraron "+e.getRecompensaDunab()+" DUNAB");}actualizar();mensaje(alta?"Inscripción realizada. ¡Ganaste "+e.getRecompensaDunab()+" DUNAB!":"Inscripción cancelada. Se retiraron "+e.getRecompensaDunab()+" DUNAB de tu progreso.");}else mensaje(alta?"No fue posible inscribirte: revisa si ya estás inscrito o no hay cupos.":"No tienes una inscripción para cancelar.");}
    private void mostrarHistorial(){StringBuilder s=new StringBuilder("MI HISTORIAL DE ACTIVIDAD\n\n");for(modelo.Actividad a:actividad.historial(usuario.getEstudiante().getCodigo()))s.append(a.getFecha().toString().replace('T',' ')).append(" | ").append(a.getAccion()).append(" | ").append(a.getDetalle()).append("\n");if(actividad.historial(usuario.getEstudiante().getCodigo()).isEmpty())s.append("Todavía no tienes actividad registrada.");JTextArea area=new JTextArea(s.toString(),16,55);area.setEditable(false);JOptionPane.showMessageDialog(this,new JScrollPane(area),"Mi historial",JOptionPane.INFORMATION_MESSAGE);}
    private void mostrarRanking(){Map<String,Integer> r=gestor.ranking();java.util.List<Map.Entry<String,Integer>> l=new ArrayList<Map.Entry<String,Integer>>(r.entrySet());l.sort((a,b)->b.getValue().compareTo(a.getValue()));StringBuilder s=new StringBuilder("RANKING DE PARTICIPACIÓN\n\n");int i=1;for(Map.Entry<String,Integer> e:l)s.append(i++).append(". Código ").append(e.getKey()).append(" — ").append(e.getValue()).append(" actividades\n");s.append("\nTotal encuentros: ").append(gestor.total()).append("\nTotal inscripciones: ").append(gestor.totalInscripciones());JOptionPane.showMessageDialog(this,s.toString(),"Ranking y progreso",JOptionPane.INFORMATION_MESSAGE);}
    private void mensaje(String s){JOptionPane.showMessageDialog(this,s);}
}
