package modelo;
import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
public class Encuentro implements Serializable {
    private static final long serialVersionUID = 1L;
    private int id;
    private String titulo, materia, descripcion, creadorCodigo, lugar, categoria;
    private LocalDate fecha;
    private int cupoMaximo;
    private List<String> inscritos;
    public Encuentro(int id,String titulo,String materia,String descripcion,String creadorCodigo,
                     String lugar,String categoria,LocalDate fecha,int cupoMaximo) {
        this.id=id; this.titulo=titulo; this.materia=materia; this.descripcion=descripcion;
        this.creadorCodigo=creadorCodigo; this.lugar=lugar; this.categoria=categoria;
        this.fecha=fecha; this.cupoMaximo=cupoMaximo; this.inscritos=new ArrayList<String>();
    }
    public int getId(){return id;} public String getTitulo(){return titulo;}
    public String getMateria(){return materia;} public String getDescripcion(){return descripcion;}
    public String getCreadorCodigo(){return creadorCodigo;} public String getLugar(){return lugar;}
    public String getCategoria(){return categoria;} public LocalDate getFecha(){return fecha;}
    public int getCupoMaximo(){return cupoMaximo;} public List<String> getInscritos(){return inscritos;}
    /** Recompensa DUNAB por categoría. Crear el encuentro no otorga puntos. */
    public int getRecompensaDunab(){
        if("Estudio".equalsIgnoreCase(categoria)) return 100;
        if("Académico".equalsIgnoreCase(categoria) || "Academico".equalsIgnoreCase(categoria)) return 200;
        if("Social".equalsIgnoreCase(categoria)) return 150;
        if("Deportivo".equalsIgnoreCase(categoria)) return 250;
        return 0;
    }
    public void setTitulo(String v){titulo=v;} public void setMateria(String v){materia=v;}
    public void setDescripcion(String v){descripcion=v;} public void setLugar(String v){lugar=v;}
    public void setCategoria(String v){categoria=v;} public void setFecha(LocalDate v){fecha=v;}
    public void setCupoMaximo(int v){cupoMaximo=v;}
    public boolean agregarInscrito(String codigo){if(inscritos.contains(codigo)||inscritos.size()>=cupoMaximo)return false; inscritos.add(codigo);return true;}
    public boolean quitarInscrito(String codigo){return inscritos.remove(codigo);}
    public int getCuposDisponibles(){return Math.max(0,cupoMaximo-inscritos.size());}
}
