package modelo;
import java.io.Serializable;
import java.time.LocalDateTime;
public class Notificacion implements Serializable {
 private static final long serialVersionUID=1L;
 private final int id; private final String destinatario,titulo,mensaje; private final LocalDateTime fecha; private boolean leida;
 public Notificacion(int id,String destinatario,String titulo,String mensaje){this.id=id;this.destinatario=destinatario;this.titulo=titulo;this.mensaje=mensaje;this.fecha=LocalDateTime.now();this.leida=false;}
 public int getId(){return id;} public String getDestinatario(){return destinatario;} public String getTitulo(){return titulo;} public String getMensaje(){return mensaje;} public LocalDateTime getFecha(){return fecha;} public boolean isLeida(){return leida;} public void marcarLeida(){leida=true;}
}
