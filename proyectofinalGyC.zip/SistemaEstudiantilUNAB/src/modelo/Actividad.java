package modelo;
import java.io.Serializable; import java.time.LocalDateTime;
public class Actividad implements Serializable {
 private static final long serialVersionUID=1L;
 private final String codigo,accion,detalle; private final LocalDateTime fecha;
 public Actividad(String codigo,String accion,String detalle){this.codigo=codigo;this.accion=accion;this.detalle=detalle;this.fecha=LocalDateTime.now();}
 public String getCodigo(){return codigo;} public String getAccion(){return accion;} public String getDetalle(){return detalle;} public LocalDateTime getFecha(){return fecha;}
}
