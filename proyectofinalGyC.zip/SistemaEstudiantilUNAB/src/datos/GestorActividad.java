package datos;
import modelo.Actividad; import java.io.*; import java.util.*;
public class GestorActividad {
 private final File archivo=new File("datos","actividades.dat"); private final List<Actividad> datos=cargar();
 @SuppressWarnings("unchecked") private List<Actividad> cargar(){if(!archivo.exists())return new ArrayList<Actividad>();try(ObjectInputStream in=new ObjectInputStream(new FileInputStream(archivo))){return (List<Actividad>)in.readObject();}catch(Exception e){return new ArrayList<Actividad>();}}
 public void registrar(String codigo,String accion,String detalle){datos.add(new Actividad(codigo,accion,detalle));try{File d=archivo.getParentFile();if(!d.exists())d.mkdirs();try(ObjectOutputStream out=new ObjectOutputStream(new FileOutputStream(archivo))){out.writeObject(datos);}}catch(IOException e){throw new IllegalStateException("No se pudo guardar el historial",e);}}
 public List<Actividad> historial(String codigo){List<Actividad> r=new ArrayList<Actividad>();for(Actividad a:datos)if(a.getCodigo().equals(codigo))r.add(a);r.sort((a,b)->b.getFecha().compareTo(a.getFecha()));return r;}
 public int contar(String codigo){return historial(codigo).size();}
 /** Los puntos se calculan en GestorEncuentros según las inscripciones activas, no por crear actividades. */
 public int puntos(String codigo){return 0;}
 public int puntosPorAccion(String codigo,String accion){int total=0;for(Actividad a:historial(codigo))if(accion.equals(a.getAccion()))total++;return total;}
}
