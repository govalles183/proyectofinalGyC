package datos;
import modelo.Encuentro;
import java.io.*;
import java.time.LocalDate;
import java.util.*;
public class GestorEncuentros {
    private final File archivo = new File("datos","encuentros.dat");
    private final List<Encuentro> encuentros = cargar();
    public GestorEncuentros(){sembrarEjemplosPorCategoria();}
    private void sembrarEjemplosPorCategoria(){
        String[][] ejemplos={
            {"Estudio","Grupo de estudio: Cálculo Integral","Cálculo Integral","Repaso colaborativo de integrales y ejercicios tipo parcial.","Biblioteca UNAB"},
            {"Académico","Taller de programación Java","Programación","Espacio práctico para resolver retos de Java y compartir soluciones.","Laboratorio de informática"},
            {"Social","Bienvenida y integración estudiantil","Integración","Actividad para conocer estudiantes de otros programas y compartir.","Plazoleta principal"},
            {"Deportivo","Encuentro deportivo universitario","Deporte","Jornada recreativa de fútbol y actividades deportivas.","Cancha deportiva UNAB"}
        };
        boolean cambio=false;
        for(String[] ejemplo:ejemplos){
            boolean existe=false;
            for(Encuentro e:encuentros) if(ejemplo[0].equalsIgnoreCase(e.getCategoria())){existe=true;break;}
            if(!existe){
                int id=1;for(Encuentro e:encuentros)if(e.getId()>=id)id=e.getId()+1;
                encuentros.add(new Encuentro(id,ejemplo[1],ejemplo[2],ejemplo[3],"DUNAB",ejemplo[4],ejemplo[0],LocalDate.now().plusDays(7+id),30));
                cambio=true;
            }
        }
        if(cambio) guardar();
    }
    @SuppressWarnings("unchecked")
    private List<Encuentro> cargar(){
        if(!archivo.exists()) return new ArrayList<Encuentro>();
        try(ObjectInputStream in=new ObjectInputStream(new FileInputStream(archivo))){
            return (List<Encuentro>)in.readObject();
        }catch(Exception ex){return new ArrayList<Encuentro>();}
    }
    private boolean guardar(){
        File dir=archivo.getParentFile(); if(!dir.exists()&&!dir.mkdirs())return false;
        try(ObjectOutputStream out=new ObjectOutputStream(new FileOutputStream(archivo))){out.writeObject(encuentros);return true;}
        catch(IOException ex){return false;}
    }
    public List<Encuentro> listar(){return new ArrayList<Encuentro>(encuentros);}
    public Encuentro buscar(int id){for(Encuentro e:encuentros)if(e.getId()==id)return e;return null;}
    public boolean crear(String titulo,String materia,String descripcion,String creador,String lugar,String categoria,LocalDate fecha,int cupos){
        if(vacio(titulo)||vacio(materia)||vacio(creador)||vacio(lugar)||fecha==null||cupos<1)return false;
        int id=1;for(Encuentro existente:encuentros)if(existente.getId()>=id)id=existente.getId()+1;
        encuentros.add(new Encuentro(id,titulo.trim(),materia.trim(),descripcion==null?"":descripcion.trim(),creador,lugar.trim(),categoria,fecha,cupos));
        return guardar();
    }
    public boolean editar(int id,String titulo,String materia,String descripcion,String lugar,String categoria,LocalDate fecha,int cupos){
        Encuentro e=buscar(id); if(e==null||vacio(titulo)||vacio(materia)||fecha==null||cupos<e.getInscritos().size()||cupos<1)return false;
        e.setTitulo(titulo.trim());e.setMateria(materia.trim());e.setDescripcion(descripcion);e.setLugar(lugar.trim());e.setCategoria(categoria);e.setFecha(fecha);e.setCupoMaximo(cupos);return guardar();
    }
    public boolean eliminar(int id,String codigo){Encuentro e=buscar(id);if(e==null||!e.getCreadorCodigo().equals(codigo))return false;encuentros.remove(e);return guardar();}
    public boolean inscribir(int id,String codigo){Encuentro e=buscar(id);if(e==null||vacio(codigo)||!e.agregarInscrito(codigo))return false;return guardar();}
    public boolean cancelar(int id,String codigo){Encuentro e=buscar(id);if(e==null||!e.quitarInscrito(codigo))return false;return guardar();}
    public List<Encuentro> buscarTexto(String q){List<Encuentro> r=new ArrayList<Encuentro>();String x=q==null?"":q.toLowerCase();for(Encuentro e:encuentros)if(e.getTitulo().toLowerCase().contains(x)||e.getMateria().toLowerCase().contains(x)||e.getDescripcion().toLowerCase().contains(x))r.add(e);return r;}
    public List<Encuentro> filtrarCategoria(String c){List<Encuentro> r=new ArrayList<Encuentro>();for(Encuentro e:encuentros)if("Todas".equals(c)||e.getCategoria().equals(c))r.add(e);return r;}
    public List<Encuentro> historial(String codigo){List<Encuentro> r=new ArrayList<Encuentro>();for(Encuentro e:encuentros)if(e.getCreadorCodigo().equals(codigo)||e.getInscritos().contains(codigo))r.add(e);return r;}
    public Map<String,Integer> ranking(){Map<String,Integer> r=new HashMap<String,Integer>();for(Encuentro e:encuentros){r.put(e.getCreadorCodigo(),r.containsKey(e.getCreadorCodigo())?r.get(e.getCreadorCodigo())+1:1);for(String c:e.getInscritos())r.put(c,r.containsKey(c)?r.get(c)+1:1);}return r;}
    public int total(){return encuentros.size();}
    public int totalInscripciones(){int n=0;for(Encuentro e:encuentros)n+=e.getInscritos().size();return n;}
    /** Puntos por las inscripciones que siguen activas; cancelar inscripción retira su recompensa. */
    public int puntosDunab(String codigo){int total=0;for(Encuentro e:encuentros)if(e.getInscritos().contains(codigo))total+=e.getRecompensaDunab();return total;}
    public int cantidadInscripciones(String codigo){int total=0;for(Encuentro e:encuentros)if(e.getInscritos().contains(codigo))total++;return total;}
    public int puntosPorCategoria(String codigo,String categoria){int total=0;for(Encuentro e:encuentros)if(e.getCategoria().equalsIgnoreCase(categoria)&&e.getInscritos().contains(codigo))total+=e.getRecompensaDunab();return total;}
    public int cantidadPorCategoria(String codigo,String categoria){int total=0;for(Encuentro e:encuentros)if(e.getCategoria().equalsIgnoreCase(categoria)&&e.getInscritos().contains(codigo))total++;return total;}
    private boolean vacio(String s){return s==null||s.trim().isEmpty();}
}
