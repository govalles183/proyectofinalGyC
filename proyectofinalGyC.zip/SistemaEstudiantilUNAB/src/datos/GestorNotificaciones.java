package datos;
import modelo.Notificacion; import java.io.*; import java.util.*;
public class GestorNotificaciones {
 private final File archivo=new File("datos","notificaciones.dat"); private final List<Notificacion> datos=cargar();
 @SuppressWarnings("unchecked") private List<Notificacion> cargar(){if(!archivo.exists())return new ArrayList<Notificacion>();try(ObjectInputStream in=new ObjectInputStream(new FileInputStream(archivo))){return (List<Notificacion>)in.readObject();}catch(Exception e){return new ArrayList<Notificacion>();}}
 private void guardar(){try{File d=archivo.getParentFile();if(!d.exists())d.mkdirs();try(ObjectOutputStream out=new ObjectOutputStream(new FileOutputStream(archivo))){out.writeObject(datos);}}catch(IOException e){throw new IllegalStateException("No se pudieron guardar las notificaciones",e);}}
 public void agregar(String codigo,String titulo,String mensaje){if(codigo==null||codigo.trim().isEmpty())return;int id=datos.isEmpty()?1:datos.get(datos.size()-1).getId()+1;datos.add(new Notificacion(id,codigo,titulo,mensaje));guardar();}
 public List<Notificacion> listar(String codigo){List<Notificacion> r=new ArrayList<Notificacion>();for(Notificacion n:datos)if(n.getDestinatario().equals(codigo))r.add(n);r.sort((a,b)->b.getFecha().compareTo(a.getFecha()));return r;}
 public int noLeidas(String codigo){int n=0;for(Notificacion x:datos)if(x.getDestinatario().equals(codigo)&&!x.isLeida())n++;return n;}
 public void marcarLeida(int id,String codigo){for(Notificacion n:datos)if(n.getId()==id&&n.getDestinatario().equals(codigo)){n.marcarLeida();guardar();return;}}
 public void marcarTodas(String codigo){for(Notificacion n:datos)if(n.getDestinatario().equals(codigo))n.marcarLeida();guardar();}
}
